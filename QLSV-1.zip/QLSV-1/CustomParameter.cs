﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLSV_1
{
    public class CustomParameter
    {
        public string key { get; set; }
        public string value { get; set; }
    }
}
